﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace crud.Models
{
    public class Aluno
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="O nome é obrigatório")] 
        [StringLength(100, MinimumLength = 3, ErrorMessage = "O campo nome deve ter entre 3 e 100 caracteres")]
        public String? Nome { get; set; }

        public int Idade { get; set; }

        public float NotaPrimeiroSemestre { get; set; }

        public float NotaSegundoSemestre { get; set; }

        [StringLength(100, MinimumLength = 3, ErrorMessage = "O campo nome deve ter entre 3 e 100 caracteres")]
        public String? NomeProfessor { get; set; }

        public int NumeroSala { get; set; }
    }
}
