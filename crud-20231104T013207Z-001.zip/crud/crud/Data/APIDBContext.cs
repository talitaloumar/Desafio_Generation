﻿using crud.Models;
using Microsoft.EntityFrameworkCore;

namespace crud.Data
{
    public class APIDBContext : DbContext
    {
        public APIDBContext(DbContextOptions<APIDBContext> options): base(options)
        {

        }
        public DbSet<Aluno>? Aluno { get; set; }

    }
}